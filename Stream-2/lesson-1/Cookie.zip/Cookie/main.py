from flask import Flask, request, render_template, redirect, url_for, make_response
from db import *
from hs import hashing

app = Flask(__name__)

@app.route('/')
def home():
    username = request.cookies.get('session')

    if username == hashing('admin'):
        flag_file = open('static/flag.txt', 'r')
        flag = flag_file.read()
    else:
        flag = None
    return render_template('home.html', flag = flag)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if (username is not None) and (password is not None) and authenticate_user(username, password):
            response = make_response(redirect(url_for('home')))
            response.set_cookie(
                'session', 
                hashing(username), 
                max_age=60
            )
        else:
            response = make_response(redirect(url_for('login', error='authorization_failed')))
        
        return response
    else:
        return render_template('login.html')
    
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if ((username != None) & (password != None)):
            add_user(username, password)
            response = make_response(redirect(url_for('login')))
        
        return response
    else:
        return render_template('register.html')

if __name__ == '__main__':
    app.run(port=8080, debug=True)