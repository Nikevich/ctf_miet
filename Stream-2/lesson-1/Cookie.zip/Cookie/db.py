import csv

filename = 'static/users.csv'

def add_user(username, password):
    with open(filename, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([username, password])

def authenticate_user(username, password):
    try:
        with open(filename, mode='r') as file:
            reader = csv.reader(file)
            for row in reader:
                if row[0] == username:
                    return row[1] == password
        return False
    except FileNotFoundError:
        print("Файл не найден.")
        return False