import hashlib

def hashing(string):
    return hashlib.sha256(string.encode('utf-8')).hexdigest()